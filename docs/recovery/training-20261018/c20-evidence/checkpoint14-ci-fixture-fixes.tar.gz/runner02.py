import pathlib,json,hashlib,subprocess,fcntl,time,os,socket,shutil,secrets
root=pathlib.Path('/workspace/scratch/5a77e8bdc1ae');repo=root/'eduk12_c20_20261018';backend=repo/'server-version/backend';tools=root/'eduk12_tools_20261018';node=tools/'node_modules/node/bin/node';out=root/'c20-ci-fix-02';out.mkdir();lock=(tools/'.measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert shutil.disk_usage(root).free > 8*1024**3+350*1024**2
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();files=subprocess.check_output(['git','ls-files','-z','server-version/backend'],cwd=repo).split(b'\0');capture=lambda:{os.fsdecode(f):sha(repo/os.fsdecode(f)) for f in files if f};before=capture();(out/'source-before.json').write_text(json.dumps(before,indent=2));diff=subprocess.check_output(['git','diff','--','server-version/backend'],cwd=repo);(out/'input.patch').write_bytes(diff)
result={'head':head,'inputPatchSha256':sha(out/'input.patch'),'passed':False,'phases':[],'nodeSha256':sha(node)}
def port():
 s=socket.socket();s.bind(('127.0.0.1',0));p=s.getsockname()[1];s.close();return p
pgport=port();redisport=port();pg=tools/'postgresql/bin';password=secrets.token_hex(20);pw=out/'pg-password-private';pw.write_text(password);pw.chmod(0o600)
url=f'postgresql://c20_ci:{password}@127.0.0.1:{pgport}/c20_ci';env={**os.environ,'PATH':str(node.parent)+':'+str(pg)+':'+os.environ['PATH'],'NODE_ENV':'test','TZ':'UTC','COGNITIVE_MODULE_ENABLED':'true','DATABASE_URL':url,'PGPASSWORD':password,'DATA_ENCRYPTION_KEY':'a'*64,'REDIS_URL':f'redis://127.0.0.1:{redisport}'}
for key in ['V32_1_INTEGRATION_DATABASE_URL','WORKC_QUERY_BUDGET_DATABASE_URL','PR8_INTEGRATION_DATABASE_URL','SITUATIONAL_BUNDLE_INTEGRATION_DATABASE_URL']:env[key]=url
processes=[]
def run(name,argv,cwd=backend,timeout=180):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 result['phases'].append({'name':name,'argv':argv,'exitCode':r.returncode,'seconds':time.monotonic()-start,'logSha256':sha(out/(name+'.log'))});(out/'result.json').write_text(json.dumps(result,indent=2));return r.returncode
try:
 assert run('initdb',[str(pg/'initdb'),'-D',str(out/'pgdata'),'-U','c20_ci','--pwfile='+str(pw),'--auth=scram-sha-256','--encoding=UTF8','--locale=C'])==0
 processes.append(subprocess.Popen([str(pg/'postgres'),'-D',str(out/'pgdata'),'-h','127.0.0.1','-p',str(pgport),'-k','','-c','timezone=UTC'],stdout=(out/'postgres.log').open('w'),stderr=subprocess.STDOUT,env=env))
 processes.append(subprocess.Popen([str(tools/'redis/bin/redis-server'),'--bind','127.0.0.1','--port',str(redisport),'--save','','--appendonly','no','--dir',str(out)],stdout=(out/'redis.log').open('w'),stderr=subprocess.STDOUT,env=env))
 for i in range(60):
  r=subprocess.run([str(pg/'psql'),'-h','127.0.0.1','-p',str(pgport),'-U','c20_ci','-d','postgres','-Atc','SELECT 1'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if r.returncode==0 and r.stdout.strip()==b'1':break
  time.sleep(.25)
 else:raise RuntimeError('PG protocol readiness timeout')
 assert run('create-db',[str(pg/'createdb'),'-h','127.0.0.1','-p',str(pgport),'-U','c20_ci','c20_ci'])==0
 assert run('migrations',[str(node),'node_modules/prisma/build/index.js','migrate','deploy'],timeout=240)==0
 inventory=json.loads((root/'pr314-ci-diagnosis/backend-failure-inventory.json').read_text());failed=json.loads((root/'c20-ci-fix-01/tests.json').read_text());tests=[t['name'].split('/server-version/backend/')[1] for t in failed['testResults'] if any(a['status']=='failed' for a in t['assertionResults'])];result['predecessorResultSha256']=sha(root/'c20-ci-fix-01/result.json');result['testEnvironment']={'COGNITIVE_MODULE_ENABLED':'true','source':'.github/workflows/ci-backend-regression.yml'}
 code=run('affected-tests',[str(node),'node_modules/vitest/vitest.mjs','run',*tests,'--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'tests.json')],timeout=300)
 result['passed']=code==0
finally:
 for p in reversed(processes):
  p.terminate()
  try:p.wait(timeout=20)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 after=capture();result['sourceUnchanged']=before==after and subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head;result['cleanupVerified']=all(p.poll() is not None for p in processes);(out/'source-after.json').write_text(json.dumps(after,indent=2));result['passed'] &= result['sourceUnchanged'] and result['cleanupVerified'];(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps({'passed':result['passed'],'sourceUnchanged':result['sourceUnchanged'],'cleanupVerified':result['cleanupVerified'],'phases':[{'name':x['name'],'exitCode':x['exitCode'],'seconds':x['seconds']} for x in result['phases']]}));lock.close()

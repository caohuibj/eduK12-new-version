import { compileWeightedVariants, weightedVariantConfigSchema } from '../assessment-core/weighted-variants'
import { buildTrainingVariantUnion } from '../composite/training-variant-scope'
import { assertTrainingVariantAuthoringScope } from './training-variant-authoring'
import { assertTrainingFlowAuthoringScope, compileTrainingFlowDefinition, hasTrainingFlowDefinition, remapTrainingFlowDraft, trainingFlowSchema, validateTrainingFlow } from './training-flow-authoring'
import {freezeTrainingTimingPolicy,readTrainingTimingPolicy} from '../assessment-runtime/training-scale-timing'
import { remapTrainingFormDefinition } from '../assessment-runtime/form-policy'
import { typedCompositeFormQuestion } from '../assessment-runtime/typed-form'
import { assertCognitiveProductEligible, isCognitiveProductEligible, isCognitiveNewAdmissionEnabled } from '../cognitive/product-eligibility'
import { assertCognitiveCatalogConfiguration } from '../cognitive/assignment.service'
import { Prisma, UserRole } from '@prisma/client'
import { randomUUID } from 'node:crypto'
import { prisma } from '../../config/database'
import { canonicalHash } from '../assessment-runtime/canonical'
import { lockCompositeAssetReferences, compositeSjtGrantScope, inspectCompositeSituationalItems, resolveCompositeSituationalItems, assertValidItem, getCompositeForTeacher, publishComposite, prepareCompositePublication, listAvailableForStudent } from '../composite/composite.service'
import { compositeBadRequest, compositeConflict, compositeForbidden, compositeNotFound } from '../composite/composite.errors'
import { mapCompositeSection, compositeFormSectionDefinitionHash } from '../assessment-runtime/form-section-definition'
import { compositeFormSectionImageReferences, publishedFormMediaOwner, retainFormSectionImages } from '../assessment-runtime/form-image.adapter'
import { compositeFormSectionVideoPresentations, retainFormSectionVideos } from '../assessment-runtime/form-video.adapter'
import { ensureCompositeFormSections } from '../composite/final-submit.service'
import { addCompositeItemSchema } from '../composite/composite.schema'
import { canUseScale } from '../../services/materialGrant'
import { situationalReleaseKey, listSituationalResourceSummaries } from '../situational/situational-release.service'
import { freezeAssignmentProfile, freezeDataForWrite } from '../cognitive/profile-freeze'
import { requireCognitiveRegistryEntry } from '../cognitive/cognitive.registry'
import { z } from 'zod'

type Actor = { userId: string; role: UserRole }
type Tx = Prisma.TransactionClient
const author = (a: Actor) => { if (!['ADMIN', 'TEACHER'].includes(a.role)) throw compositeForbidden() }
const owner = (a: Actor, row: { createdBy: string | null }) => {
  author(a)
  if (a.role !== 'ADMIN' && row.createdBy !== a.userId) throw compositeForbidden()
}
const metadata = {
  trainingTimingEnabled: z.boolean().optional(),
  name: z.string().trim().min(1, '请填写问卷名称').max(200, '问卷名称不能超过200字'), description: z.string().max(5000).nullable().optional(),
  instruction: z.string().max(10000).nullable().optional(), courseIds: z.array(z.string().min(1)).max(100).default([]),
  publicEnabled: z.boolean().default(false), opensAt: z.string().datetime().nullable().optional(), expiresAt: z.string().datetime().nullable().optional(),
}
export const createSchema = z.object({ ...metadata, requestId: z.string().uuid(), questionnaireType: z.enum(['COURSE', 'GENERAL']) }).strict()
export const editSchema = z.object({ ...metadata, revision: z.number().int().nonnegative() }).strict()
export const trainingVariantsSchema = z.object({
  revision: z.number().int().nonnegative(), config: weightedVariantConfigSchema.nullable(),
  maxAttempts: z.number().int().min(1).max(100).optional(),
}).strict()
export const revisionSchema = z.object({ revision: z.number().int().nonnegative() }).strict()
export const itemSchema = z.object({ revision: z.number().int().nonnegative(), item: addCompositeItemSchema, formSectionId: z.string().min(1).optional() }).strict()
export const orderSchema = z.object({ revision: z.number().int().nonnegative(),
  units: z.array(z.object({ id: z.string().min(1), type: z.enum(['FORM_SECTION', 'SCALE', 'COGNITIVE', 'SITUATIONAL']) }).strict()).min(1).max(500),
}).strict()
const date = (v?: string | null) => v ? new Date(v) : null
const windowCheck = (v: { publicEnabled: boolean; opensAt?: string | null; expiresAt?: string | null }) => {
  if (v.publicEnabled && !v.expiresAt) throw compositeBadRequest('公开问卷必须设置有效期')
  if (v.opensAt && v.expiresAt && new Date(v.opensAt) > new Date(v.expiresAt)) throw compositeBadRequest('结束时间不能早于开始时间')
}
async function courses(tx: Tx, actor: Actor, ids: string[], type: string) {
  if (new Set(ids).size !== ids.length) throw compositeBadRequest('课程不能重复')
  if (type === 'GENERAL' && ids.length) throw compositeBadRequest('通用问卷不绑定课程')
  const rows = await tx.course.findMany({ where: { id: { in: ids } } })
  if (rows.length !== ids.length || rows.some(r => r.isLibrary || (actor.role !== 'ADMIN' && r.creatorId !== actor.userId))) throw compositeForbidden('只能投放到有管理权限的非库课程')
}
async function timingPolicy(tx:Tx, row:any, enabled:boolean) {
 if(!enabled)return Prisma.DbNull
 if(row.questionnaireType!=='COURSE'||row.productKind!=='QUESTIONNAIRE'||row.reportPackageKey||row.analysisProtocolKey)throw compositeBadRequest('计时仅支持 Training 课程普通问卷')
 const ids=(row.questionnaireCourses??[]).map((x:any)=>x.courseId)
 const facts=await tx.course.findMany({where:{id:{in:ids}},select:{id:true,courseType:true,isLibrary:true}})
 if(facts.length!==ids.length)throw compositeBadRequest('计时课程来源缺失')
 return freezeTrainingTimingPolicy(facts,row.publicEnabled)
}
export async function updateTimingExport(actor:Actor,id:string,raw:unknown){
 const input=z.object({revision:z.number().int().nonnegative(),enabled:z.boolean()}).strict().parse(raw)
 return mutate(actor,id,input.revision,async(tx,row)=>{
  await tx.compositeAssessment.update({where:{id},data:{timingExportEnabled:input.enabled}})
  await tx.assessmentManagementEvent.create({data:{actorId:actor.userId,resourceId:id,action:'TRAINING_TIMING_EXPORT_POLICY',metadata:{previous:row.timingExportEnabled,enabled:input.enabled,revision:row.revision+1}}})
 },false)
}
/** Explicit opt-in; the ordinary null configuration is never inferred or backfilled. */
export async function updateTrainingVariants(actor: Actor, id: string, raw: unknown) {
  const input = trainingVariantsSchema.parse(raw)
  return mutate(actor, id, input.revision, async (tx, row) => {
    if (input.config === null) {
      if (input.maxAttempts !== undefined) throw compositeBadRequest('关闭分组时不能同时改变作答次数')
      await tx.compositeAssessment.update({ where: { id }, data: {
        trainingVariantDraft: Prisma.DbNull, trainingVariantFrozen: Prisma.DbNull, trainingVariantDigest: null,
      } })
      return
    }
    const candidate = { ...row, maxAttempts: input.maxAttempts ?? row.maxAttempts }
    await assertTrainingVariantAuthoringScope(tx, candidate)
    compileWeightedVariants(input.config, buildTrainingVariantUnion(candidate))
    await tx.compositeAssessment.update({ where: { id }, data: {
      trainingVariantDraft: input.config as Prisma.InputJsonValue,
      trainingVariantFrozen: Prisma.DbNull, trainingVariantDigest: null, maxAttempts: candidate.maxAttempts,
    } })
  })
}
/** Explicit opt-in. No flow is inferred from a legacy questionnaire layout. */
export async function updateTrainingFlow(actor: Actor, id: string, raw: unknown) {
  const input = trainingFlowSchema.parse(raw)
  return mutate(actor, id, input.revision, async (tx, row) => {
    if(input.maxAttempts!==undefined&&input.config?.schemaVersion!==2)throw compositeBadRequest('作答预算仅随明确材料实验设置')
    const candidate={...row,trainingFlowDraft:input.config,maxAttempts:input.maxAttempts??row.maxAttempts}
    if (input.config !== null) {
      await assertTrainingFlowAuthoringScope(tx, candidate)
      compileTrainingFlowDefinition(input.config, candidate)
    }
    await tx.compositeAssessment.update({ where: { id }, data: {
      trainingFlowDraft: input.config === null ? Prisma.DbNull : input.config as Prisma.InputJsonValue,
      trainingFlowFrozen: Prisma.DbNull, trainingFlowDigest: null, ...(input.maxAttempts!==undefined?{maxAttempts:input.maxAttempts}:{}),
    } })
  })
}
async function validateTrainingVariants(tx: Tx, row: any) {
  if (row.trainingVariantDraft == null) return
  await assertTrainingVariantAuthoringScope(tx, row)
  return compileWeightedVariants(row.trainingVariantDraft, buildTrainingVariantUnion(row))
}
export async function detail(actor: Actor, id: string) {
  const row = await prisma.compositeAssessment.findUnique({ where: { id } })
  if (!row || row.productKind !== 'QUESTIONNAIRE') throw compositeNotFound('新版问卷不存在')
  owner(actor, row)
  return { ...await getCompositeForTeacher(actor.userId, actor.role, id), supportedChannels: ['WEB'], reportMode: 'COLLECTION_ONLY' }
}
export async function create(actor: Actor, raw: unknown) {
  author(actor)
  if (process.env.QUESTIONNAIRE_PRODUCTS_ENABLED === 'false') throw compositeConflict('暂未开放新版问卷创建')
  const input = createSchema.parse(raw)
  windowCheck(input)
  const creationKey = actor.userId + ':' + input.requestId
  const creationHash = canonicalHash(input)
  const run = () => prisma.$transaction(async tx => {
    const existing = await tx.compositeAssessment.findUnique({ where: { creationKey } })
    if (existing) {
      if (existing.creationHash !== creationHash) throw compositeConflict('同一创建请求不能更换内容')
      return existing.id
    }
    await courses(tx, actor, input.courseIds, input.questionnaireType)
    return (await tx.compositeAssessment.create({ data: {
      code: 'Q-' + randomUUID(), name: input.name, description: input.description, instruction: input.instruction,
      productKind: 'QUESTIONNAIRE', questionnaireType: input.questionnaireType, createdBy: actor.userId,
      trainingTimingPolicy: await timingPolicy(tx,{productKind:'QUESTIONNAIRE',questionnaireType:input.questionnaireType,questionnaireCourses:input.courseIds.map(courseId=>({courseId})),publicEnabled:input.publicEnabled},input.trainingTimingEnabled===true),
      creationKey, creationHash, publicEnabled: input.publicEnabled, opensAt: date(input.opensAt), expiresAt: date(input.expiresAt),
      questionnaireCourses: { create: input.courseIds.map(courseId => ({ courseId })) },
    } })).id
  })
  let id: string
  try { id = await run() } catch (e: any) { if (e.code !== 'P2002') throw e; id = await run() }
  return detail(actor, id)
}
async function mutate(actor: Actor, id: string, revision: number, fn: (tx: Tx, row: any) => Promise<void>, draft = true, noOp?: (row: any) => boolean) {
  author(actor)
  await prisma.$transaction(async tx => {
    await tx.$queryRawUnsafe('SELECT "id" FROM "composite_assessments" WHERE "id" = $1 FOR UPDATE', id)
    const row = await tx.compositeAssessment.findUnique({ where: { id }, include: {
      questionnaireCourses: true, items: { orderBy: { position: 'asc' }, include: { cognitiveAssignment: { include: { config: true } }, scale: true } },
      formSections: { orderBy: { position: 'asc' }, include: { items: true } },
    } })
    if (!row || row.productKind !== 'QUESTIONNAIRE') throw compositeNotFound('新版问卷不存在')
    owner(actor, row)
    if (row.reportPackageKey || row.analysisProtocolKey) throw compositeConflict('问卷必须只收集单项结果')
    if (noOp?.(row)) return
    if (row.revision !== revision) throw compositeConflict('问卷已被其他操作修改，请刷新后重试')
    if (draft && row.status !== 'DRAFT') throw compositeConflict('已发布问卷不能修改，请复制为新草稿')
    await fn(tx, row)
    // Keep every edit atomic with the saved group references. Authors can
    // explicitly disable grouping before changing the global unit layout.
    if (draft && row.status === 'DRAFT' && (row.trainingVariantDraft != null || hasTrainingFlowDefinition(row))) {
      const current = await tx.compositeAssessment.findUnique({ where: { id }, include: {
        questionnaireCourses: true, items: true, formSections: { include: { items: true } },
      } })
      if (current?.trainingVariantDraft != null) await validateTrainingVariants(tx, current)
      if (current) await validateTrainingFlow(tx, current)
    }
    await tx.compositeAssessment.update({ where: { id }, data: { revision: { increment: 1 } } })
  }, { timeout: 30000 })
  return detail(actor, id)
}
export async function update(actor: Actor, id: string, raw: unknown) {
  const input = editSchema.parse(raw); windowCheck(input)
  return mutate(actor, id, input.revision, async (tx, row) => {
    await courses(tx, actor, input.courseIds, row.questionnaireType)
    await tx.questionnaireCourseDelivery.deleteMany({ where: { compositeId: id } })
    await tx.questionnaireCourseDelivery.createMany({ data: input.courseIds.map(courseId => ({ compositeId: id, courseId })) })
    await tx.compositeAssessment.update({ where: { id }, data: {
      trainingTimingPolicy: await timingPolicy(tx,{...row,questionnaireCourses:input.courseIds.map(courseId=>({courseId})),publicEnabled:input.publicEnabled},input.trainingTimingEnabled??Boolean(row.trainingTimingPolicy)),
      name: input.name, description: input.description ?? null, instruction: input.instruction ?? null,
      publicEnabled: input.publicEnabled, opensAt: date(input.opensAt), expiresAt: date(input.expiresAt),
    } })
  })
}
export async function addItem(actor: Actor, id: string, raw: unknown) {
  const { revision, item, formSectionId } = itemSchema.parse(raw)
  return mutate(actor, id, revision, async (tx, row) => {
    await assertValidItem(item, actor.userId, actor.role, row, tx)
    if (row.items.length >= 500) throw compositeBadRequest('问卷最多包含 500 个内容项')
    const position = Math.max(-1, ...row.items.map((v: any) => v.position), ...row.formSections.map((v: any) => v.position)) + 1
    const itemId = randomUUID()
    const targetSection = formSectionId ? row.formSections.find((section:any)=>section.id===formSectionId) : null
    if (formSectionId && (item.type!=='FORM' || !targetSection || targetSection.contextSection || item.contextKey)) throw compositeBadRequest('只能加入当前草稿已有的普通表单区段')
    if (targetSection) {
      const ordered = [...row.items].sort((a:any,b:any)=>a.position-b.position)
      const start = ordered.findIndex((value:any)=>value.formSectionId===targetSection.id)
      if (start < 0 || ordered.slice(start).some((value:any)=>value.formSectionId!==targetSection.id)) throw compositeBadRequest('只能追加到末尾连续表单区段；请创建新区段，不能跨越后续内容')
    }
    await tx.compositeAssessmentItem.create({ data: {
      id: itemId,
      ...(targetSection ? {formSectionId:targetSection.id, formSectionPosition:Math.max(-1,...targetSection.items.map((child:any)=>child.formSectionPosition??child.position))+1}: {}),
      ...(item.type==='FORM' && item.formPolicy ? {formPolicy:item.formPolicy}: {}),
      ...(item.type === 'FORM' && item.formDefinition ? { formDefinition: { ...item.formDefinition, itemKey: 'q_' + itemId } as Prisma.InputJsonValue } : {}),
      compositeAssessmentId: id, type: item.type, position, required: item.required,
      scaleId: item.type === 'SCALE' ? item.scaleId : null, cognitiveAssignmentId: item.type === 'COGNITIVE' ? item.cognitiveAssignmentId : null,
      situationalInstrumentKey: item.type === 'SITUATIONAL' ? item.situationalInstrumentKey : null,
      situationalInstrumentVersion: item.type === 'SITUATIONAL' ? item.situationalInstrumentVersion : null,
      formType: item.type === 'FORM' ? item.formType : null, formLabel: item.type === 'FORM' ? item.formLabel : null,
      formPlaceholder: item.type === 'FORM' ? item.formPlaceholder : null,
      formOptions: item.type === 'FORM' && item.formOptions ? item.formOptions : Prisma.JsonNull,
      contextKey: item.type === 'FORM' ? item.contextKey : null,
    } })
    await ensureCompositeFormSections(id, tx)
  })
}
export async function removeItem(actor: Actor, id: string, itemId: string, raw: unknown) {
  return mutate(actor, id, revisionSchema.parse(raw).revision, async (tx, row) => {
    const item = row.items.find((v: any) => v.id === itemId)
    if (!item) throw compositeNotFound('问卷内容项不存在')
    await tx.compositeAssessmentItem.delete({ where: { id: itemId } })
    if (item.formSectionId && !await tx.compositeAssessmentItem.count({ where: { formSectionId: item.formSectionId } })) await tx.compositeFormSection.delete({ where: { id: item.formSectionId } })
  })
}
export async function reorder(actor: Actor, id: string, raw: unknown) {
  const { revision, units } = orderSchema.parse(raw)
  return mutate(actor, id, revision, async (tx, row) => {
    const expected = new Map<string, string>([
      ...row.items.filter((v: any) => v.type !== 'FORM').map((v: any) => [v.id, v.type]),
      ...row.formSections.map((v: any) => [v.id, 'FORM_SECTION']),
    ])
    if (units.length !== expected.size || new Set(units.map(v => v.id)).size !== units.length || units.some(v => expected.get(v.id) !== v.type)) throw compositeBadRequest('排序必须包含全部内容单元且不能重复')
    const context = row.formSections.find((s: any) => s.contextSection || s.items.some((v: any) => v.contextKey))
    if (context && units[0]?.id !== context.id) throw compositeBadRequest('人口学上下文区段必须排在第一位')
    const base = Math.max(0, ...row.items.map((v: any) => v.position), ...row.formSections.map((v: any) => v.position)) + 1
    for (let i = 0; i < units.length; i++) {
      const unit = units[i]
      if (unit.type === 'FORM_SECTION') await tx.compositeFormSection.update({ where: { id: unit.id }, data: { position: base + i } })
      else await tx.compositeAssessmentItem.update({ where: { id: unit.id }, data: { position: base + i } })
    }
  })
}

export async function removeEmptySection(actor: Actor, id: string, sectionId: string, raw: unknown) {
  return mutate(actor, id, revisionSchema.parse(raw).revision, async (tx, row) => {
    const section = row.formSections.find((value: any) => value.id === sectionId)
    if (!section) throw compositeNotFound('表单区段不存在')
    if (section.items.length) throw compositeConflict('区段中还有字段，请先移除字段')
    await tx.compositeFormSection.delete({ where: { id: sectionId } })
  })
}
const copiedCognitiveBinding = (item: any, row: any) => item.type === 'COGNITIVE' && item.cognitiveAssignment?.listedStandalone === false
  && item.cognitiveAssignment?.createdBy === row.createdBy && item.cognitiveAssignment?.courseId === null
  && item.cognitiveAssignment?.resolvedConfigSnapshotEncrypted && item.cognitiveAssignment?.resolvedReportSnapshotEncrypted

async function validateDelivery(tx: Tx, actor: Actor, row: any) {
    if (row.questionnaireType === 'COURSE' && !row.questionnaireCourses.length) throw compositeBadRequest('请选择至少一个投放课程')
    if (row.questionnaireType === 'GENERAL' && !row.publicEnabled) throw compositeBadRequest('通用问卷需要启用公开链接')
    windowCheck({ publicEnabled: row.publicEnabled, opensAt: row.opensAt?.toISOString(), expiresAt: row.expiresAt?.toISOString() })
    await courses(tx, actor, row.questionnaireCourses.map((v: any) => v.courseId), row.questionnaireType)
}

async function validateResources(tx: Tx, actor: Actor, row: any, inspected?: Awaited<ReturnType<typeof inspectCompositeSituationalItems>>) {
  const situational = inspected?.releases ?? await resolveCompositeSituationalItems(row.items, tx, true, compositeSjtGrantScope(row))
  for (const item of row.items) {
    // Legacy storage accepts arbitrary strings. Do not publish an unknown
    // field type as a text input through the player's compatibility fallback.
    if (item.type === 'FORM' && item.formDefinition == null && !['fill_blank', 'single_choice', 'multiple_choice', 'text_input', 'year_month'].includes(item.formType)) {
      throw compositeBadRequest(`表单字段“${item.formLabel || item.id}”的题型不受支持，请在副本中重新配置后发布`)
    }
    if (copiedCognitiveBinding(item, row)) continue
    if (item.type === 'SITUATIONAL' && inspected) {
      const key = situationalReleaseKey({ instrumentKey: item.situationalInstrumentKey, instrumentVersion: item.situationalInstrumentVersion })
      if (inspected.errors.has(key)) throw inspected.errors.get(key)
    }
    await assertValidItem({ ...item, required: item.required } as any, actor.userId, actor.role, row, tx, situational)
  }
  return situational
}

export async function preflight(actor: Actor, id: string, raw: unknown) {
  author(actor)
  const { revision } = revisionSchema.parse(raw)
  return prisma.$transaction(async tx => {
    await tx.$queryRawUnsafe('SELECT "id" FROM "composite_assessments" WHERE "id" = $1 FOR SHARE', id)
    const row = await tx.compositeAssessment.findUnique({ where: { id }, include: {
      questionnaireCourses: true, formSections: { include: { items: true } }, items: { include: { cognitiveAssignment: { include: { config: true } }, scale: true } },
    } })
    if (!row || row.productKind !== 'QUESTIONNAIRE') throw compositeNotFound()
    owner(actor, row)
    if (row.revision !== revision) throw compositeConflict('草稿已变化，请刷新后重新自检')
    const inspectedSituational = await inspectCompositeSituationalItems(row.items, tx, compositeSjtGrantScope(row))
    const checks: Array<{ key: string; label: string; status: 'passed' | 'failed'; message: string; targetId?: string }> = []
    for (const [key, label, validate] of [
      ['delivery', '课程、公开投放与时间', () => validateDelivery(tx, actor, row)],
      ['training-variants', 'Training 加权分组、完整覆盖与次数限制', () => validateTrainingVariants(tx, row)],
      ['training-flow', 'Training 条件路径、材料与结束规则', () => validateTrainingFlow(tx, row)],
      ['resources', '内容依赖与当前权限', () => validateResources(tx, actor, row, inspectedSituational)],
      ['content', '区段、背景顺序、字段与冻结定义', () => {
        if (inspectedSituational.errors.size) throw inspectedSituational.errors.values().next().value
        return prepareCompositePublication(actor.userId, actor.role, id, tx, inspectedSituational.releases)
      }],
    ] as const) {
      try { await validate(); checks.push({ key, label, status: 'passed', message: '通过' }) }
      catch (cause: any) {
        if (!(cause.statusCode >= 400 && cause.statusCode < 500)) throw cause
        checks.push({ key, label, status: 'failed', message: cause.message })
      }
    }
    if (checks.some(check => check.key === 'resources' && check.status === 'failed')) {
      for (const item of row.items) {
        try { await validateResources(tx, actor, { ...row, items: [item] }, inspectedSituational) }
        catch (cause: any) {
          if (!(cause.statusCode >= 400 && cause.statusCode < 500)) throw cause
          checks.push({ key: 'resource:' + item.id, label: item.scale?.name || item.cognitiveAssignment?.title || item.formLabel || '内容依赖', status: 'failed', message: cause.message, targetId: item.formSectionId || item.id })
        }
      }
    }
    if (checks.some(check => check.key === 'content' && check.status === 'failed')) {
      for (const section of row.formSections.filter(section => !section.items.length)) checks.push({ key: 'section:' + section.id, label: section.title, status: 'failed', message: '移除空区段或在当前草稿补齐字段，再重新自检。', targetId: section.id })
    }
    if(row.trainingTimingPolicy){try{await timingPolicy(tx,row,true);checks.push({key:'timing',label:'可选计时来源',status:'passed',message:'通过'})}catch(cause:any){if(!(cause.statusCode>=400&&cause.statusCode<500))throw cause;checks.push({key:'timing',label:'可选计时来源',status:'failed',message:cause.message})}}
    return { revision, ok: checks.every(check => check.status === 'passed'), checks, reportMode: 'COLLECTION_ONLY' }
  }, { timeout: 30000 })
}

export async function publish(actor: Actor, id: string, raw: unknown) {
  return mutate(actor, id, revisionSchema.parse(raw).revision, async (tx, row) => {
    if (await tx.assessmentCompositionTemplate.findUnique({ where: { definitionId: id } })) throw compositeConflict('组合模板需要先复制为新草稿，再绑定课程或公开投放')
    if(row.trainingVariantDraft!=null)await validateTrainingVariants(tx,row)
    await validateDelivery(tx, actor, row)
    const situational = await validateResources(tx, actor, row)
    await lockCompositeAssetReferences(tx, row.items, row.formSections, situational)
    for (const item of row.items) {
      const copiedBinding = copiedCognitiveBinding(item, row)
      if (item.type === 'COGNITIVE' && !copiedBinding) {
        const source = item.cognitiveAssignment
        const entry = requireCognitiveRegistryEntry(source.config.testType, source.config.engineVersion, source.config.scoringVersion)
        const freeze = source.resolvedConfigSnapshotEncrypted ? {
          profile: source.profile, profileDefinitionVersion: source.profileDefinitionVersion,
          resolvedConfigSnapshotEncrypted: source.resolvedConfigSnapshotEncrypted, resolvedConfigHash: source.resolvedConfigHash,
          resolvedReportSnapshotEncrypted: source.resolvedReportSnapshotEncrypted,
        } : freezeDataForWrite(freezeAssignmentProfile({ entry, baseConfig: entry.configSchema.parse(source.config.config), profile: 'standard' }))
        const binding = await tx.cognitiveAssignment.create({ data: {
          configId: source.configId, createdBy: actor.userId, title: source.title, instruction: source.instruction,
          status: 'PUBLISHED', publishedAt: new Date(), listedStandalone: false, required: false, ...freeze,
          quotaSourceAssignmentId: source.createdBy === actor.userId ? source.quotaSourceAssignmentId ?? source.id : null, maxAttempts: source.maxAttempts,
        } })
        await tx.compositeAssessmentItem.update({ where: { id: item.id }, data: { cognitiveAssignmentId: binding.id } })
      }
    }
    for (const section of row.formSections) {
      const definition = mapCompositeSection(section)
      const mediaOwner = publishedFormMediaOwner('COMPOSITE', id, compositeFormSectionDefinitionHash(definition))
      await retainFormSectionImages({ owner: mediaOwner, references: compositeFormSectionImageReferences(definition), db: tx })
      await retainFormSectionVideos({ owner: mediaOwner, presentations: compositeFormSectionVideoPresentations(definition), db: tx })
    }
    if(row.trainingTimingPolicy){readTrainingTimingPolicy(row.trainingTimingPolicy);await tx.compositeAssessment.update({where:{id},data:{trainingTimingPolicy:await timingPolicy(tx,row,true)}})}
    await publishComposite(actor.userId, actor.role, id, tx, situational)
  })
}
export async function archive(actor: Actor, id: string, raw: unknown) {
  return mutate(actor, id, revisionSchema.parse(raw).revision, async (tx, row) => {
    await tx.compositeAssessment.update({ where: { id }, data: { status: 'ARCHIVED', publicEnabled: false } })
    if (row.status !== 'ARCHIVED') await tx.assessmentManagementEvent.create({ data: { actorId: actor.userId, resourceId: id, action: 'ASSESSMENT_ARCHIVE', metadata: { name: row.name, previousStatus: row.status, revision: row.revision } } })
  }, false, row => row.status === 'ARCHIVED' && !row.publicEnabled)
}
export async function remove(actor: Actor, id: string, raw: unknown) {
  author(actor)
  await prisma.$transaction(async tx => {
    await tx.$queryRawUnsafe('SELECT "id" FROM "composite_assessments" WHERE "id" = $1 FOR UPDATE', id)
    const row = await tx.compositeAssessment.findUnique({ where: { id }, include: { _count: { select: { attempts: true } }, items: { select: { cognitiveAssignmentId: true } } } })
    if (!row || row.productKind !== 'QUESTIONNAIRE') throw compositeNotFound()
    owner(actor, row)
    if (row.revision !== revisionSchema.parse(raw).revision || row.status !== 'DRAFT' || row._count.attempts) throw compositeConflict('只能删除没有作答记录的当前草稿')
    await tx.compositeAssessment.delete({ where: { id } })
    await tx.cognitiveAssignment.deleteMany({ where: {
      id: { in: row.items.map(v => v.cognitiveAssignmentId).filter((v): v is string => Boolean(v)) },
      createdBy: row.createdBy, listedStandalone: false, courseId: null,
      compositeItems: { none: {} }, sessions: { none: {} },
    } })
  })
}
export async function list(actor: Actor, page = 1, pageSize = 25, raw: unknown = {}) {
  author(actor)
  const filters = z.object({ search: z.string().trim().max(200).default(''), status: z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED', 'DEPRECATED']).optional(), since: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(value => !Number.isNaN(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value, '创建日期无效').optional() }).strict().parse(raw)
  const search = '%' + filters.search.toLowerCase().replace(/[\\%_]/g, '\\$&') + '%'
  // SQL is static; values remain positional parameters, never interpolated.
  const union = "SELECT id, name, status::text, created_at AS created, creator_id AS owner_id, 'LEGACY' AS kind, type::text AS questionnaire_type FROM questionnaires UNION ALL SELECT c.id, c.name, c.status::text, c.created_at AS created, c.created_by AS owner_id, CASE WHEN c.product_kind = 'QUESTIONNAIRE' THEN 'COLLECTION' ELSE 'LEGACY_COMPOSITE' END AS kind, c.questionnaire_type::text FROM composite_assessments c WHERE (c.product_kind = 'QUESTIONNAIRE' OR (c.product_kind = 'LEGACY_COMPOSITE' AND c.report_package_key IS NULL AND c.analysis_protocol_key IS NULL)) AND NOT EXISTS (SELECT 1 FROM assessment_composition_templates t WHERE t.definition_id = c.id)"
  const filter = '($1::boolean OR owner_id = $2) AND LOWER(name) LIKE $3 AND ($4::text IS NULL OR status = $4::text) AND ($5::timestamp IS NULL OR created >= $5::timestamp)'
  const [rows, counts] = await prisma.$transaction([
    prisma.$queryRawUnsafe<any[]>('SELECT * FROM (' + union + ') q WHERE ' + filter + ' ORDER BY created DESC,id,kind LIMIT $6 OFFSET $7', actor.role === 'ADMIN', actor.userId, search, filters.status ?? null, filters.since ? filters.since + 'T00:00:00.000Z' : null, pageSize, (page - 1) * pageSize),
    prisma.$queryRawUnsafe<Array<{ total: bigint }>>('SELECT COUNT(*) AS total FROM (' + union + ') q WHERE ' + filter, actor.role === 'ADMIN', actor.userId, search, filters.status ?? null, filters.since ? filters.since + 'T00:00:00.000Z' : null),
  ])
  return { list: rows.map(v => ({ ...v, reportMode: 'COLLECTION_ONLY', editHref: v.kind === 'COLLECTION' ? '/questionnaire-products/' + v.id : v.kind === 'LEGACY_COMPOSITE' ? '/composite-assessments/' + v.id : v.questionnaire_type === 'GENERAL' ? '/general-questionnaires/' + v.id + '/edit' : '/questionnaires/' + v.id })), total: Number(counts[0].total), page, pageSize }
}
export async function available(userId: string) {
  const rows = await listAvailableForStudent(userId)
  return rows.filter(v => v.productKind === 'QUESTIONNAIRE').map(v => ({
    ...v, href: v.canContinue ? '/student/composite/attempts/' + v.attempt!.id :
      v.latestCompletedAttempt && !v.canStartNewAttempt ? '/student/composite/attempts/' + v.latestCompletedAttempt.id + '/report' : '/student/composite/' + v.id,
  }))
}
export async function resources(actor: Actor) {
  author(actor)
  const [scales, cognitive, courseRows, situational] = await Promise.all([
    prisma.scale.findMany({ where: { status: 'PUBLISHED' }, orderBy: { name: 'asc' } }),
    isCognitiveNewAdmissionEnabled() ? prisma.cognitiveAssignment.findMany({ where: { status: 'PUBLISHED', listedStandalone: true, config: { status: 'PUBLISHED' }, ...(actor.role === 'ADMIN' ? {} : { createdBy: actor.userId }) }, include: { config: true }, orderBy: { title: 'asc' } }) : Promise.resolve([]),
    prisma.course.findMany({ where: { isLibrary: false, ...(actor.role === 'ADMIN' ? {} : { creatorId: actor.userId }) }, select: { id: true, title: true, courseType: true } }),
    listSituationalResourceSummaries(actor.userId),
  ])
  const usable = []
  for (const row of scales) if (await canUseScale(actor.userId, actor.role, row)) usable.push({ id: row.id, name: row.name, code: row.code, version: row.instrumentVersion })
  for (const row of cognitive.filter(v => isCognitiveProductEligible(v.config.testType))) assertCognitiveCatalogConfiguration(row.config)
  return {
    scales: usable, cognitive: cognitive.filter(v => isCognitiveProductEligible(v.config.testType)).map(v => ({ id: v.id, name: v.title, profile: v.profile, testType: v.config.testType, configVersion: v.config.configVersion, engineVersion: v.config.engineVersion, scoringVersion: v.config.scoringVersion })),
    situational,
    courses: courseRows,
  }
}

/** Copy definitions only; no attempts, responses, tokens or report ciphertext. */
export async function copy(actor: Actor, id: string, raw: unknown, options: { allowTrainingVariants?: boolean; allowTrainingFlow?: boolean } = {}) {
  author(actor)
  if (process.env.QUESTIONNAIRE_PRODUCTS_ENABLED === 'false') throw compositeConflict('暂未开放新版问卷创建')
  const { requestId } = z.object({ requestId: z.string().uuid() }).strict().parse(raw)
  const creationKey = actor.userId + ':' + requestId
  const creationHash = canonicalHash({ copySource: id })
  const run = () => prisma.$transaction(async tx => {
    const existing = await tx.compositeAssessment.findUnique({ where: { creationKey } })
    if (existing) {
      if (existing.creationHash !== creationHash) throw compositeConflict('创建请求已用于其他内容')
      if (options.allowTrainingVariants === false && (existing.trainingVariantDraft != null || existing.trainingVariantFrozen != null)) {
        throw compositeBadRequest('加权随机分组暂不支持无课程投放的私有模板，请复制为课程草稿')
      }
      if ((options.allowTrainingFlow ?? options.allowTrainingVariants) === false && hasTrainingFlowDefinition(existing)) {
        throw compositeBadRequest('跨工具流程暂不支持无课程投放的私有模板，请复制为课程草稿')
      }
      return existing.id
    }
    // Resolve storage server-side. A collision is rejected rather than guessed.
    const legacy = await tx.questionnaire.findUnique({ where: { id }, include: {
      questionnaireScales: true, formItems: true, formSections: true, courseQuestionnaires: true,
    } })
    let composite = await tx.compositeAssessment.findUnique({ where: { id }, include: { items: { include: { cognitiveAssignment: true } }, formSections: true, questionnaireCourses: true } })
    if ((!legacy && !composite) || (legacy && composite)) throw compositeNotFound('无法唯一识别来源问卷')
    owner(actor, { createdBy: legacy ? legacy.creatorId : composite!.createdBy })
    if (composite && (composite.trainingVariantDraft != null || composite.trainingVariantFrozen != null || hasTrainingFlowDefinition(composite))) {
      await tx.$queryRawUnsafe('SELECT "id" FROM "composite_assessments" WHERE "id" = $1 FOR SHARE', id)
      composite = await tx.compositeAssessment.findUnique({ where: { id }, include: { items: { include: { cognitiveAssignment: true } }, formSections: true, questionnaireCourses: true } })
      if (!composite) throw compositeNotFound('来源问卷不存在')
      owner(actor, composite)
      if (composite.trainingVariantDraft != null || composite.trainingVariantFrozen != null) {
        if (options.allowTrainingVariants === false) throw compositeBadRequest('加权随机分组暂不支持无课程投放的私有模板，请复制为课程草稿')
        if (composite.trainingVariantDraft == null) throw compositeBadRequest('来源问卷缺少加权分组定义')
        await assertTrainingVariantAuthoringScope(tx, composite)
      }
      if (hasTrainingFlowDefinition(composite)) {
        if ((options.allowTrainingFlow ?? options.allowTrainingVariants) === false) throw compositeBadRequest('跨工具流程暂不支持无课程投放的私有模板，请复制为课程草稿')
        await validateTrainingFlow(tx, composite)
      }
    }
    const source = legacy ?? composite!
    if (composite && (composite.productKind === 'ASSESSMENT_BUNDLE' || composite.reportPackageKey || composite.analysisProtocolKey)) throw compositeBadRequest('固定报告包不能复制为问卷')
    const questionnaireType = legacy?.type ?? composite!.questionnaireType ?? 'COURSE'
    const sourceCourses = legacy ? legacy.courseQuestionnaires.map(v => v.courseId) : composite!.productKind === 'LEGACY_COMPOSITE' ? (composite!.courseId ? [composite!.courseId] : []) : composite!.questionnaireCourses.map(v => v.courseId)
    await courses(tx, actor, sourceCourses, questionnaireType)
    // Optional Form fields share the existing FINAL skip contract. Preserve
    // their required flag, options and section mapping without rewriting them.
    for (const item of composite?.items ?? []) {
      if (item.cognitiveAssignment) {
        const config = await tx.cognitiveTestConfig.findUnique({ where: { id: item.cognitiveAssignment.configId } })
        if (!config) throw compositeBadRequest('来源认知任务配置不存在')
        assertCognitiveProductEligible(config.testType)
      }
    }
    if (composite) await resolveCompositeSituationalItems(composite.items, tx, true, compositeSjtGrantScope({ productKind: 'QUESTIONNAIRE', questionnaireType, questionnaireCourses: sourceCourses.map(courseId => ({courseId})), createdBy: actor.userId }))
    const target = await tx.compositeAssessment.create({ data: {
      code: 'Q-' + randomUUID(), name: source.name + '（副本）', description: source.description, instruction: source.instruction,
      productKind: 'QUESTIONNAIRE', questionnaireType, createdBy: actor.userId, creationKey, creationHash,
      ...((composite?.trainingVariantDraft != null||(composite?.trainingFlowDraft as any)?.schemaVersion===2) ? { maxAttempts: composite!.maxAttempts } : {}),
      trainingTimingPolicy:await timingPolicy(tx,{productKind:'QUESTIONNAIRE',questionnaireType,questionnaireCourses:sourceCourses.map(courseId=>({courseId})),publicEnabled:false},Boolean(composite?.trainingTimingPolicy)),
      questionnaireCourses: { create: sourceCourses.map(courseId => ({ courseId })) },
    } })
    const copiedIds = new Map<string, string>((composite?.items ?? []).map(item => [item.id, randomUUID()]))
    const copiedKeys = new Map<string, string>((composite?.items ?? []).filter(item => item.formDefinition != null).map(item => [(item.formDefinition as any).itemKey, 'q_' + copiedIds.get(item.id)]))
    const sectionIds = new Map<string, string>()
    for (const section of source.formSections) {
      const created = await tx.compositeFormSection.create({ data: {
        compositeAssessmentId: target.id, title: section.title, description: section.description,
        position: section.position, contextSection: section.contextSection,
      } })
      sectionIds.set(section.id, created.id)
    }
    if (legacy) {
      for (const scale of legacy.questionnaireScales) await tx.compositeAssessmentItem.create({ data: {
        compositeAssessmentId: target.id, type: 'SCALE', position: scale.position, required: true, scaleId: scale.scaleId,
      } })
      for (const form of legacy.formItems) await tx.compositeAssessmentItem.create({ data: {
        compositeAssessmentId: target.id, type: 'FORM', position: form.position, required: form.required,
        formType: form.type, formLabel: form.label, formPlaceholder: form.placeholder,
        formOptions: form.options ?? Prisma.JsonNull, contextKey: form.contextKey,
        formSectionId: form.sectionId ? sectionIds.get(form.sectionId) : null, formSectionPosition: form.sectionPosition,
      } })
    } else {
      for (const item of composite!.items) {
        if (item.formDefinition != null) typedCompositeFormQuestion({ ...item, placeholder: item.formPlaceholder ?? null } as any)
        const { id: _id, compositeAssessmentId: _parent, cognitiveAssignment, ...data } = item
        if (cognitiveAssignment?.listedStandalone === false) {
          const binding = await tx.cognitiveAssignment.create({ data: {
            configId: cognitiveAssignment.configId, createdBy: actor.userId, title: cognitiveAssignment.title,
            instruction: cognitiveAssignment.instruction, status: cognitiveAssignment.status,
            listedStandalone: false, required: false, profile: cognitiveAssignment.profile,
            profileDefinitionVersion: cognitiveAssignment.profileDefinitionVersion,
            resolvedConfigSnapshotEncrypted: cognitiveAssignment.resolvedConfigSnapshotEncrypted,
            resolvedConfigHash: cognitiveAssignment.resolvedConfigHash,
            resolvedReportSnapshotEncrypted: cognitiveAssignment.resolvedReportSnapshotEncrypted,
            maxAttempts: cognitiveAssignment.maxAttempts,
            quotaSourceAssignmentId: cognitiveAssignment.createdBy === actor.userId ? cognitiveAssignment.quotaSourceAssignmentId ?? cognitiveAssignment.id : null,
          } })
          data.cognitiveAssignmentId = binding.id
        }
        await tx.compositeAssessmentItem.create({ data: { ...data, id:copiedIds.get(item.id), compositeAssessmentId: target.id,
          formOptions: item.formOptions ?? Prisma.JsonNull,
          formDefinition: item.formDefinition != null ? remapTrainingFormDefinition(item.formDefinition,copiedKeys) : Prisma.DbNull,
          formPolicy: item.formPolicy ?? Prisma.DbNull,
          formSectionId: item.formSectionId ? sectionIds.get(item.formSectionId) : null,
        } })
      }
    }
    await ensureCompositeFormSections(target.id, tx)
    if (composite?.trainingVariantDraft != null) {
      const original = weightedVariantConfigSchema.parse(composite.trainingVariantDraft)
      const remapped = { ...original, groups: original.groups.map(group => ({ ...group,
        units: group.units.map(unit => {
          const mapped = (unit.type === 'FORM_SECTION' ? sectionIds : copiedIds).get(unit.id)
          if (!mapped) throw compositeBadRequest('来源分组引用了不存在的内容单元，请先修复原草稿')
          return { ...unit, id: mapped }
        }),
      })) }
      const copied = await tx.compositeAssessment.findUniqueOrThrow({ where: { id: target.id }, include: {
        questionnaireCourses: true, items: true, formSections: { include: { items: true } },
      } })
      await assertTrainingVariantAuthoringScope(tx, copied)
      // Recompile all remapped definition references; the new draft does not
      // inherit the source's immutable publication digest or allocation data.
      compileWeightedVariants(remapped, buildTrainingVariantUnion(copied))
      await tx.compositeAssessment.update({ where: { id: target.id }, data: {
        trainingVariantDraft: remapped as Prisma.InputJsonValue,
        trainingVariantFrozen: Prisma.DbNull, trainingVariantDigest: null,
      } })
    }
    if (composite?.trainingFlowDraft != null) {
      const remapped = remapTrainingFlowDraft(composite.trainingFlowDraft, sectionIds, copiedIds, copiedKeys)
      const copied = await tx.compositeAssessment.findUniqueOrThrow({ where: { id: target.id }, include: {
        questionnaireCourses: true, items: true, formSections: { include: { items: true } },
      } })
      await assertTrainingFlowAuthoringScope(tx, copied)
      compileTrainingFlowDefinition(remapped, copied)
      await tx.compositeAssessment.update({ where: { id: target.id }, data: {
        trainingFlowDraft: remapped as Prisma.InputJsonValue, trainingFlowFrozen: Prisma.DbNull, trainingFlowDigest: null,
      } })
    }
    return target.id
  }, { timeout: 30000 })
  let target: string
  try { target = await run() } catch (e: any) { if (e.code !== 'P2002') throw e; target = await run() }
  return detail(actor, target)
}

/** Paged audience-projected reports, never raw response tables. */
export async function exportReports(actor: Actor, id: string, raw: unknown) {
  const definition = await detail(actor, id)
  const { after } = z.object({ after: z.string().uuid().optional() }).strict().parse(raw)
  if (definition.trainingVariantDraft != null || definition.trainingVariantFrozen != null || definition.trainingVariantDigest != null) {
    const { getTrainingVariantReportsForTeacher } = await import('../composite/composite.service')
    const page = await getTrainingVariantReportsForTeacher(actor.userId, actor.role, id, after)
    return { schemaVersion: 'questionnaire-independent-reports-v1', reportMode: 'COLLECTION_ONLY', questionnaireId: id, ...page }
  }
  const rows = await prisma.compositeAssessmentAttempt.findMany({
    where: { compositeAssessmentId: id, status: 'COMPLETED', ...(after ? { id: { gt: after } } : {}) },
    orderBy: { id: 'asc' }, take: 101, select: { id: true },
  })
  const { getReportForTeacher } = await import('../composite/composite.service')
  const reports = []
  for (const row of rows.slice(0,100)) reports.push(await getReportForTeacher(actor.userId, actor.role, id, row.id))
  return { schemaVersion: 'questionnaire-independent-reports-v1', reportMode: 'COLLECTION_ONLY', questionnaireId: id,
    reports, next: rows.length > 100 ? rows[99].id : null }
}

#!/usr/bin/env python3
"""Generate review-only EduK12 native content candidates; no network/DB/scoring engine."""
from __future__ import annotations
import argparse, hashlib, json, pathlib, uuid

ROOT = pathlib.Path(__file__).resolve().parent
VERSION = '0.1.0'
BASE = 'd7d43535c8eac445918ae113a43b1cc04032d310'
TEACH_URL = 'https://documents1.worldbank.org/curated/en/872291641201520569/pdf/Teach-Primary-Observer-Manual.pdf'
RTOP_URL = 'https://www.physport.org/assessments/pdfs/RTOP_Reference_Manual.pdf'


def text(key: str, prompt: str, *, required: bool = False, length: int = 1200) -> dict:
    return dict(itemKey=key, type='LONG_TEXT', prompt=prompt, required=required,
                options=[], rows=[], maxLength=length)


def choice(key: str, prompt: str, options: list[tuple[str, str]], *, required: bool = True) -> dict:
    return dict(itemKey=key, type='SINGLE', prompt=prompt, required=required,
                options=[dict(optionKey=k, label=v) for k, v in options], rows=[])


def page(key: str, title: str, questions: list[dict], description: str = '') -> dict:
    return dict(pageKey=key, title=title, description=description, questions=questions)


def form(pages: list[dict]) -> dict:
    return dict(schemaVersion=2, pages=pages)


def score(key: str, label: str, items: list[str], description: str, *, total: bool = False) -> dict:
    return dict(key=key, type='total' if total else 'dimension', label=label,
                description=description, direction='descriptive', canonical=True,
                displayPrecision=0, source=dict(type='items', aggregation='sum',
                items=[dict(itemCode=i, weight=1) for i in items]))


def scale(title: str, prompts: list[tuple[str, str]], minimum: int, maximum: int,
          scores: list[dict], source: dict, limitations: list[str], license_note: str,
          license_status: str = 'unknown', redistribution: str = 'unknown') -> dict:
    return dict(schemaVersion=2, respondentType='observer_report', source=source,
        license=dict(status=license_status, redistribution=redistribution, note=license_note),
        display=dict(randomizeItems=False),
        responseSets=[dict(key='rating', options=[dict(value=i, label=str(i), score=i)
                       for i in range(minimum, maximum+1)])],
        items=[dict(itemCode=k, content=p, type='single', required=True, sortOrder=i,
                    responseSetKey='rating', randomizeOptions=False) for i,(k,p) in enumerate(prompts)],
        scoring=dict(scoringVersion=VERSION, itemRules=[dict(itemCode=k, transform=dict(type='identity'))
                     for k,_ in prompts], defaultMissingPolicy=dict(type='complete_required'), scores=scores),
        report=dict(reportVersion=VERSION,
            audienceContract=dict(schemaVersion=1, respondent='OBSERVER_REPORT', audience='teacher',
                                  locale='zh-CN', longitudinalMetricKeys=[]),
            primaryScoreKeys=[s['key'] for s in scores if s['type']=='total'] or [s['key'] for s in scores],
            scoreOrder=[s['key'] for s in scores],
            interpretations=[dict(scoreKey=s['key'], headline=s['label'], source=dict(type='score_only'),
                summary=s['description'], bands=[], guidance=[dict(category='reflection',
                text='请将本次结果与同一课堂、同一观察时段的具体证据一起讨论；不要据此推断教师的稳定能力。'),
                dict(category='strategy', text='选择一项可观察的教学行动作为下一步尝试，并在后续课堂重新收集证据。')])
                for s in scores], limitations=limitations,
            disclaimer='这是观察记录的描述性结果，不是常模、诊断、排名或教师绩效结论。报告可见范围由既有发布与授权规则决定。'),
        referencePolicy=dict(type='none'))


def instruction(message: str, source: str) -> dict:
    return dict(schemaVersion=1, text=message, language='zh-CN', version=VERSION, source=source)


def build_content() -> dict[str, dict]:
    out: dict[str, dict] = {}
    out['forms/context.json'] = form([page('context', '课堂基本信息', [
        text('lesson', '课题与学科；不重复填写系统已绑定的教师姓名或账号。', required=True, length=200),
        text('grade', '年级、班级或课程背景；使用项目内编号，不记录学生姓名。', length=200),
        text('time_window', '观察日期、开始/结束时间与时区。', required=True, length=200),
        choice('mode', '本次观察方式', [('live','现场观察'),('video','经许可的课堂录像')]),
        text('goals', '本节课的学习目标与观察关注点。', length=1200),
        text('context_notes', '可能影响本次观察解释的事实背景；不要将背景推测计入评分。', length=800)
    ], '同一次组合由同一观察者填写。评价对象与活动由系统绑定，本表不产生权限或分数。')])
    out['forms/evidence.json'] = form([page('evidence', '课堂证据记录', [
        text('evidence_log', '按“时点｜指标或条目编号｜实际看到/听到的行为｜必要的上下文”记录；区分事实与推断。', required=True, length=6000),
        text('counter_evidence', '与初步判断不一致的证据，以及未能观察的范围。', length=2000),
        text('evidence_limits', '观察中断、遮挡、录音不清或资料缺失等限制。', length=1200)
    ], '不上传学生个人信息；本次不增加附件上传、定时采样或行为统计功能。')])
    out['forms/observer-feedback.json'] = form([page('feedback', '观察者的专业反馈', [
        text('strength', '一项有具体课堂证据支持的优势。', length=1200),
        text('priority', '一项优先改进点，写明对应的事实证据。', length=1200),
        text('action', '建议在下一次课堂尝试的具体行动与拟观察的变化。', length=1200),
        text('discussion', '尚需与授课教师讨论的问题；不要代填授课教师的反思或同意。', length=1200)
    ], '这里记录观察者意见，不是自动反馈报告。教师本人反思需走其独立身份下的任务或既有协作记录。')])
    areas = [
        ('learning','学生学习','记录学生如何理解任务、参与思考、表达疑问及呈现学习成果；指出观察到的差异与未覆盖的学生。'),
        ('instruction','教师教学','记录任务组织、解释、提问、回应与调整的具体片段，并写明学生随后出现的可观察反应。'),
        ('curriculum','课程性质','记录目标、学习内容、任务和评价证据之间的联系；区分教材安排与课堂实际发生的内容。'),
        ('culture','课堂文化','记录发言机会、不同观点的处理、合作规则及安全表达的具体事实，不给课堂贴总体标签。')]
    out['forms/licc-inspired.json'] = form([page('focus','观察任务约定',[
        text('focus_question','本次希望用课堂证据回答的一个问题。',required=True,length=800),
        text('observation_scope','约定观察对象、时段与记录方法；没有观察的范围明确留空。',length=1000)],
        '基于LICC四维框架编制的EduK12原创记录模板，不是LICC原68观察点全文或标准化量表。')]+
        [page(k,l,[text(k+'_facts',p,length=3000),text(k+'_question','由上述事实提出的待讨论问题；与事实记录分开。',length=1200)]) for k,l,p in areas])
    segment = [
        text('segment_times','本段实际开始、结束时间和持续分钟数；有延迟或提前结束时如实记录。',required=True,length=200),
        text('segment_context','本段主题、班级人数及观察限制；仅记录必要的去身份化资料。',length=800)]
    snapshots = []
    for minute in (4,9,14):
        prefix = f'snapshot_{minute}'
        status=choice(prefix+'_status',f'第{minute}分钟快照是否实际完成？', [('taken','已完成'),('missed','未完成；保持缺失，不补成0或N/A')])
        activity=choice(prefix+'_activity','0.1 Teacher provides learning activity to most students', [('Y','Y'),('N','N')])
        activity['displayIf']=dict(itemKey=prefix+'_status',operator='EQUALS',optionKey='taken')
        on_task=choice(prefix+'_on_task','0.2 Students are on task：0.1=N时选N/A；否则按原手册人数规则编码。', [('NA','N/A'),('L','L'),('M','M'),('H','H')])
        on_task['displayIf']=dict(itemKey=prefix+'_status',operator='EQUALS',optionKey='taken')
        note=text(prefix+'_note','实际采样时间、观察事实或漏采原因。',length=600)
        snapshots.append(page(prefix,f'第{minute}分钟快照',[status,activity,on_task,note],
            '使用1–10秒扫视；0.1=Y时，离任务人数0–1记H，2–5记M，6及以上记L。表单只保存编码，不自动判级或计算比例。'))
    out['forms/teach-snapshots.json'] = form([page('segment','Teach Primary 本段背景',segment)]+snapshots)
    data = json.loads((ROOT/'teach-data.json').read_text(encoding='utf-8'))
    behavior_pages=[]
    for element in data['elements']:
        qs=[]
        for b in element['behaviors']:
            opts=[('L','L'),('M','M'),('H','H')]
            if b['code'] in ('1.3','4.2'): opts=[('NA','N/A')]+opts
            key='b_'+b['code'].replace('.','_')
            qs.append(choice(key,b['code']+' '+b['text'],opts))
        qs.append(text('evidence_'+str(element['number']), '记录本要素的事实证据及对应行为编号。',required=True,length=2400))
        behavior_pages.append(page('element_'+str(element['number']),element['label'],qs,
            '查阅原手册完整L/M/H锚点后编码。1.4先记录a、b，再手动判定：任一L则L；两项M则M；其余无L且至少一项H则H。NA只用于原手册允许的行为。'))
    out['forms/teach-behaviors.json']=form(behavior_pages)
    prompts=[(f'E{e["number"]}', f'{e["number"]}. {e["label"]}：根据本段证据与原手册，录入最终1–5分；不是将L/M/H求平均。') for e in data['elements']]
    scores=[score(f'e{e["number"]}',e['label'],[f'E{e["number"]}'],
        f'本段“{e["label"]}”的观察者评定，范围1–5；数值直接保留，不代表百分位或长期能力。') for e in data['elements']]
    out['scales/teach-element-ratings.definition.json']=scale('Teach Primary 要素评定录入',prompts,1,5,scores,
        dict(title='Teach Primary (Second Edition, 2021)',publicationYear=2021,url=TEACH_URL,
        citation=data['attribution']),
        ['数字化拆分与中文操作提示为EduK12适配，非世界银行官方译本；原始英文名称及手册锚点为依据。',
         '本组件仅含一个观察段的9个要素分；两段分别保留，不新增跨段、跨维度总分。',
         '完整行为锚点、FAQ与观察培训使用原手册；本包不包括环境质量附加清单。',
         '没有足够观察依据时，不以低分代替缺失；保留观察记录并按项目方案处理未完成评分。'],
        data['adaptationDisclaimer']+' '+data['translationDisclaimer'], 'verified','allowed')
    out['scales/teach-element-ratings.instruction.json']=instruction(
        '仅供学习过原手册的观察者使用。观察并编码本段后，再录入9个要素1–5分。1、3、5对应原手册低、中、高整体描述；2、4是相邻水平之间的判断。不要将L/M/H机械平均。第二段必须独立观察。'+
        '原手册：'+TEACH_URL, 'World Bank, Teach Primary, Second Edition (2021), pp.13–15,20,26–38.')
    rtop_groups=[('lesson_design','教学设计与实施',1,5),('propositional','学科概念内容',6,10),
                 ('procedural','思考与探究过程',11,15),('communication','课堂交流',16,20),('relationships','师生互动关系',21,25)]
    rtop_scores=[score(k,l,[f'R{i:02}' for i in range(a,b+1)],f'原表第{a}–{b}项的描述性合计，范围0–20；不是当地常模。') for k,l,a,b in rtop_groups]
    rtop_scores.append(score('total','RTOP原始总分',[f'R{i:02}' for i in range(1,26)],
                            '原表25项0–4分的合计，范围0–100。高低必须结合观察目的、课堂证据与原手册解释。',total=True))
    out['scales/rtop-score-entry.definition.json']=scale('RTOP原表配套评分录入',
        [(f'R{i:02}',f'RTOP原表第{i:02}项：请对照原始题表及评分手册，录入0–4分。') for i in range(1,26)],0,4,rtop_scores,
        dict(title='RTOP score-entry companion; original instrument: ACEPT IN00-1/IN00-3',publicationYear=2000,url=RTOP_URL,
             citation='Piburn, M., & Sawada, D. (2000). Reformed Teaching Observation Protocol (RTOP): Reference Manual. ACEPT Technical Report IN00-3.'),
        ['这是原表配套评分录入工具，不包含25条原始题文，也不是新译本；必须同时使用原始题表与完整锚点。',
         '0是原量尺中的有效最低评分，不等于未观察或缺失；无法形成评分时不得用0补齐。',
         '保留五个原分区及总分；不引入百分位、优秀/合格阈值或教师排名。'],
        '原RTOP权利状态单独标记，需联系作者/权利人确认拟用范围；此包不镜像原题表。元数据不新增平台门禁。')
    out['scales/rtop-score-entry.instruction.json']=instruction(
        '本工具仅录入已经依据原始RTOP题表形成的25项评分。必须先打开原表并学习完整评分锚点，不得将编号提示当作原题。'+
        '逐项录入0–4分，完整作答后由现有量表引擎计算五个分区与总分。不知道或未观察不等于0。原手册：'+RTOP_URL,
        'ACEPT Technical Report IN00-3; PhysPort RTOP implementation guide.')
    return out


def recipes() -> dict[str, dict]:
    shared='本组合由同一位受邀观察者完成。量表负责计分；表单不计分；无跨工具总分、综合画像或自动纵向比较。'
    plans={
      'licc':('LICC框架下的原创课堂观察记录',[('context','forms/context.json'),('licc','forms/licc-inspired.json'),('feedback','forms/observer-feedback.json')]),
      'rtop':('RTOP原表配套课堂观察',[('context','forms/context.json'),('evidence','forms/evidence.json'),('rating','scales/rtop-score-entry.definition.json'),('feedback','forms/observer-feedback.json')]),
      'teach-primary':('Teach Primary两段观察·核心过程质量',[('context','forms/context.json'),('segment1_snapshots','forms/teach-snapshots.json'),('segment1_behaviors','forms/teach-behaviors.json'),('segment1_ratings','scales/teach-element-ratings.definition.json'),('segment2_snapshots','forms/teach-snapshots.json'),('segment2_behaviors','forms/teach-behaviors.json'),('segment2_ratings','scales/teach-element-ratings.definition.json'),('feedback','forms/observer-feedback.json')])}
    out={}
    for key,(title,slots) in plans.items():
        out['recipes/'+key+'.json']=dict(recipeVersion=1,key=key,version=VERSION,title=title,
            nativeContract='privateCompositionDefinitionSchema',nativeSchemaVersion=2,adapterVersion='2.0.0',
            administration=dict(population='TEACHER',responseMode='EXPERT_REPORT',targetKind='PERSON'),
            instruction=shared,slots=[dict(slotKey=s,contentPath=p,kind='FORM' if p.startswith('forms/') else 'SCALE',
            instruction=('第1段：独立记录本段证据。' if s.startswith('segment1') else '第2段：不得借用第1段证据。' if s.startswith('segment2') else '')+
            ('先依原手册判分，再录入；本包不提供自动判分。' if s.endswith('ratings') else '')) for s,p in slots])
    return out


def materialize(recipe: dict, bindings: dict) -> dict:
    """Assemble existing V2 shape from actual server-returned version references; no grants."""
    blocks=[]
    for slot in recipe['slots']:
        ref=bindings.get(slot['contentPath'])
        if not isinstance(ref,dict): raise ValueError('缺少服务器返回的固定来源：'+slot['contentPath'])
        provider=ref.get('provider')
        allowed=['PRIVATE_VERSION','PUBLIC_FORM'] if slot['kind']=='FORM' else ['PRIVATE_VERSION','LIBRARY_SCALE','STANDARD_SCALE']
        if provider not in allowed or ref.get('kind')!=slot['kind']: raise ValueError('来源类型不匹配：'+slot['contentPath'])
        uuid.UUID(ref['versionId'])
        h=ref['contentHash']
        if len(h)!=64 or any(c not in '0123456789abcdef' for c in h): raise ValueError('contentHash必须来自服务器')
        source={k:ref[k] for k in ('provider','kind','versionId','contentHash')}
        if provider=='STANDARD_SCALE' and 'selectedBinding' in ref: source['selectedBinding']=ref['selectedBinding']
        blocks.append(dict(blockId=str(uuid.uuid5(uuid.NAMESPACE_URL,'eduk12:classroom:'+recipe['key']+':'+recipe['version']+':'+slot['slotKey'])),
                           instruction=slot['instruction'],source=source))
    return dict(schemaVersion=2,adapterVersion='2.0.0',administration=recipe['administration'],instruction=recipe['instruction'],blocks=blocks)


def dump(path: pathlib.Path, value: dict) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def build(destination: pathlib.Path) -> dict:
    files=build_content()|recipes()
    entries=[]
    for name,value in files.items():
        dump(destination/name,value)
        entries.append(dict(path=name,sha256=hashlib.sha256((destination/name).read_bytes()).hexdigest()))
    manifest=dict(packageKey='eduk12_classroom_observation_candidates',version=VERSION,baseline=BASE,
        status='CANDIDATE_NOT_INSTALLED',forms=6,scales=2,recipes=3,files=entries,
        forbiddenClaims=['production_installed','native_validator_passed','official_translation','all_original_instruments_complete'],
        educationExpertApplicability=dict(schemaVersion=2,administrations=[dict(population='TEACHER',responseMode='EXPERT_REPORT',targetKind='PERSON')]),
        suggestedTags=['课堂观察','听评课','观察者评定','非诊断','固定版本'],
        tagNote='建议标签，不是已注册的classificationTags；发布时选择系统现有合法标签。',
        bindingNote='recipe仅是离线装配清单。必须使用服务器实际返回的versionId/contentHash；文件SHA256不是发布contentHash。')
    dump(destination/'manifest.json',manifest)
    return manifest


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('build'); p.add_argument('--out',type=pathlib.Path,required=True)
    p=sub.add_parser('bind'); p.add_argument('--recipe',type=pathlib.Path,required=True);p.add_argument('--bindings',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True)
    args=parser.parse_args()
    if args.command=='build': print(json.dumps(build(args.out),ensure_ascii=False,indent=2))
    else:
        recipe=json.loads(args.recipe.read_text(encoding='utf-8')); bindings=json.loads(args.bindings.read_text(encoding='utf-8'))
        dump(args.out,materialize(recipe,bindings));print(str(args.out))

if __name__=='__main__': main()

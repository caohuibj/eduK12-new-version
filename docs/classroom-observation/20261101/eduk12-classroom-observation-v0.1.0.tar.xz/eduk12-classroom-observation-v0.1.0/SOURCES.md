# 来源与完整性台账

核对日期：2026-11-01。以下“全文可获得”不表示本包已完整复制、已取得所有用途授权或已在系统发布。

## Teach Primary

- 原始文献：Molina et al. (2021), *Teach Primary (Second Edition)*, World Bank。
- 官方手册：https://documents1.worldbank.org/curated/en/872291641201520569/pdf/Teach-Primary-Observer-Manual.pdf
- 核对位置：版权页 PDF 第 4 页；印刷页 13–15 的观察/编码规则；印刷页 20 的完整记录表；后续行为锚点。原 PDF 已通过页面截图核对，不只依赖检索摘要。
- 许可：按手册印刷文本记录 Creative Commons Attribution 4.0 IGO；手册印刷许可链接为 https://creativecommons.org/licenses/by/4.0/ 。署名、改编和非官方译本声明保存在 teach-data.json 中并保留在本包。
- 本包：英文行为名称、两段采集结构及中文操作提示；9 个要素分独立记录。28 主行为加 1.4a/b 两个子字段，共 30 个行为记录字段；不声称 30 个独立心理测量条目。
- 未含：完整逐级锚点文字、培训视频、环境质量附加清单、第三方照片与标志。使用时必须结合原手册。
- 科学声明：本包数字化与中文提示未单独完成跨文化效度或观察者一致性研究，不冒称原工具全部证据自动迁移。

## RTOP

- 原始文献：Piburn, M., & Sawada, D. (2000), *Reformed Teaching Observation Protocol (RTOP): Reference Manual*, ACEPT Technical Report IN00-3。
- 开发者资料分发页：https://www.physport.org/assessments/assessment.cfm?A=RTOP
- 原手册：https://www.physport.org/assessments/pdfs/RTOP_Reference_Manual.pdf
- 已核对：原表 25 项、0–4 评分、五个连续五项分区、总分 0–100。工具/实施说明的相关表格通过 PDF 截图核对。
- 本包只包含“原表第 n 项”的评分录入位置、确定的分区与描述性反馈，不包含原题文；不能脱离原表独立施测。
- 权利：公共获取不等于自由再分发。标记 unknown / 需联系作者确认拟用范围，不伪造许可，不新增平台门禁。

## LICC

- 原框架来源：华东师范大学课程与教学研究所相关公开资料。
- 来源入口：https://kcs.ecnu.edu.cn/bf/a4/c48313a704420/page.htm
- 补充来源：https://kcs.ecnu.edu.cn/bf/b8/c48313a704440/page.htm
- 结构：学生学习、教师教学、课程性质、课堂文化四个维度；完整框架另含 20 个视角与 68 个观察点。
- 本包为参考四维结构编写的原创证据记录表，不转抄或假称原 68 点全文；没有原量表总分、效度或官方授权声明。

## 系统合同

精确基线：`d7d43535c8eac445918ae113a43b1cc04032d310`。

| 已读取源码 | Git blob SHA |
| --- | --- |
| `server-version/backend/src/modules/assessment-core/form/definition.ts` | `269514b731b6caa3cea0b2cf17fd18d46d918cc8` |
| `server-version/backend/src/modules/scale/scale-definition.ts` | `a55d88014baa1c3979d43cb8733acb41ea32a90a` |
| `server-version/backend/src/modules/education-tools/private-tool.definition.ts` | `efb501b0efb045bee261743d5eeaf28a0f6fc58c` |
| `server-version/backend/src/modules/education-tools/private-tool.composition-contracts.ts` | `839bcfa0d5b22816525ffd97bed6a491968a9da9` |
| `server-version/backend/src/modules/scale/onboarding/types.ts` | `5681b8519e46ecfd3190a0c408d378fb0c3c432d` |

也核对了仓库 `AGENTS.md`、`docs/release/README.md`、Teacher 现场观察管理/来源合同及 scale-scoring 的函数签名。代码静态阅读不代表运行或发布验证。

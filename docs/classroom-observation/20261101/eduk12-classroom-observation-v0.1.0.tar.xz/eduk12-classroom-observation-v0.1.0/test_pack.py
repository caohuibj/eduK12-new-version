#!/usr/bin/env python3
"""Offline artifact checks only; NOT native engine, DB, browser, or CI evidence."""
from __future__ import annotations
import hashlib, json, pathlib, platform, tempfile, time, unittest, uuid
import build_pack as p
ROOT=pathlib.Path(__file__).resolve().parent

class ContentChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.files=p.build_content(); cls.recipes=p.recipes()
    def test_01_inventory(self):
        self.assertEqual(len([x for x in self.files if x.startswith('forms/')]),6)
        self.assertEqual(len([x for x in self.files if x.endswith('.definition.json')]),2)
        self.assertEqual(len(self.recipes),3)
    def test_02_forms_have_no_scoring_or_report(self):
        def walk(x):
            if isinstance(x,dict):
                self.assertFalse({'score','scoring','report','rawScoreFeedback'} & x.keys())
                for v in x.values():walk(v)
            elif isinstance(x,list):
                for v in x:walk(v)
        for name,d in self.files.items():
            if name.startswith('forms/'):walk(d)
    def test_03_form_keys_limits_and_conditions(self):
        for name,d in self.files.items():
            if not name.startswith('forms/'):continue
            self.assertEqual(d['schemaVersion'],2);self.assertLessEqual(len(d['pages']),40)
            seen={};bytes_budget=2
            self.assertEqual(len({x['pageKey'] for x in d['pages']}),len(d['pages']))
            for page in d['pages']:
                self.assertTrue(page['title']);self.assertLessEqual(len(page['questions']),80)
                for q in page['questions']:
                    self.assertNotIn(q['itemKey'],seen);self.assertTrue(q['prompt']);self.assertLessEqual(len(q['options']),30)
                    if q['type']=='SINGLE':self.assertGreaterEqual(len(q['options']),2)
                    self.assertEqual(len({o['optionKey'] for o in q['options']}),len(q['options']))
                    if 'displayIf' in q:
                        c=q['displayIf'];self.assertIn(c['itemKey'],seen)
                        self.assertIn(c['optionKey'],[o['optionKey'] for o in seen[c['itemKey']]['options']])
                    seen[q['itemKey']]=q
                    bytes_budget+=6*q.get('maxLength',0)+len(json.dumps(q['options']))+len(q['itemKey'])+40
            self.assertLessEqual(len(seen),300);self.assertLessEqual(bytes_budget,480000)
    def test_04_scale_native_shape_and_references(self):
        for name,d in self.files.items():
            if not name.endswith('.definition.json'):continue
            self.assertEqual(d['schemaVersion'],2);self.assertEqual(d['respondentType'],'observer_report')
            self.assertEqual(len(d['responseSets']),1)
            items={x['itemCode'] for x in d['items']};scores={x['key'] for x in d['scoring']['scores']}
            self.assertEqual(len(items),len(d['items']));self.assertEqual(len(scores),len(d['scoring']['scores']))
            self.assertEqual({x['itemCode'] for x in d['scoring']['itemRules']},items)
            self.assertTrue(all(x['required'] for x in d['items']))
            self.assertEqual(d['scoring']['defaultMissingPolicy'],{'type':'complete_required'})
            self.assertNotIn('scorerKey',d['scoring']);self.assertEqual(d['referencePolicy'],{'type':'none'})
            self.assertEqual(set(d['report']['scoreOrder']),scores)
            self.assertEqual({x['scoreKey'] for x in d['report']['interpretations']},scores)
            for s in d['scoring']['scores']:
                self.assertEqual(s['source']['type'],'items');self.assertNotIn('range',s)
                self.assertTrue(all(x['itemCode'] in items and x['weight']==1 for x in s['source']['items']))
    def test_05_rtop_original_partition_and_ranges(self):
        d=self.files['scales/rtop-score-entry.definition.json']
        self.assertEqual(len(d['items']),25);self.assertEqual([x['value'] for x in d['responseSets'][0]['options']],list(range(5)))
        s=d['scoring']['scores'];self.assertEqual(len(s),6)
        self.assertEqual([len(x['source']['items']) for x in s],[5,5,5,5,5,25])
        self.assertEqual([x['itemCode'] for x in s[-1]['source']['items']],[f'R{i:02}' for i in range(1,26)])
        self.assertEqual([y['itemCode'] for x in s[:-1] for y in x['source']['items']],[f'R{i:02}' for i in range(1,26)])
        self.assertEqual(25*4,100) # design arithmetic, not an executed native scorer
    def test_06_teach_nine_scores_no_total(self):
        d=self.files['scales/teach-element-ratings.definition.json']
        self.assertEqual(len(d['items']),9);self.assertEqual(len(d['scoring']['scores']),9)
        self.assertEqual([x['value'] for x in d['responseSets'][0]['options']],[1,2,3,4,5])
        self.assertTrue(all(x['type']=='dimension' and len(x['source']['items'])==1 for x in d['scoring']['scores']))
    def test_07_teach_behavior_identity_and_na(self):
        d=self.files['forms/teach-behaviors.json'];q=[q for pg in d['pages'] for q in pg['questions'] if q['type']=='SINGLE']
        self.assertEqual(len(q),30) # 28 behavior codes plus 1.4a and 1.4b
        self.assertEqual({q['itemKey'] for q in q if any(o['optionKey']=='NA' for o in q['options'])},{'b_1_3','b_4_2'})
        self.assertTrue({'b_1_4','b_1_4a','b_1_4b'} <= {x['itemKey'] for x in q})
    def test_08_teach_snapshot_windows_and_missing(self):
        d=self.files['forms/teach-snapshots.json']
        self.assertEqual([x['pageKey'] for x in d['pages']][1:],['snapshot_4','snapshot_9','snapshot_14'])
        for pg in d['pages'][1:]:
            self.assertEqual([x['optionKey'] for x in pg['questions'][0]['options']],['taken','missed'])
            self.assertEqual([x['optionKey'] for x in pg['questions'][2]['options']],['NA','L','M','H'])
    def test_09_licc_is_original_four_area_form(self):
        d=self.files['forms/licc-inspired.json']
        self.assertEqual([x['pageKey'] for x in d['pages']],['focus','learning','instruction','curriculum','culture'])
        self.assertIn('不是LICC原68',d['pages'][0]['description'])
    def test_10_recipes_resolve_known_content(self):
        for r in self.recipes.values():
            self.assertEqual(r['administration'],{'population':'TEACHER','responseMode':'EXPERT_REPORT','targetKind':'PERSON'})
            self.assertLessEqual(len(r['slots']),50)
            self.assertEqual(len({x['slotKey'] for x in r['slots']}),len(r['slots']))
            for s in r['slots']:self.assertIn(s['contentPath'],self.files)
    def test_11_teach_segments_do_not_merge(self):
        r=self.recipes['recipes/teach-primary.json']
        self.assertEqual([x['slotKey'] for x in r['slots']],[ 'context','segment1_snapshots','segment1_behaviors','segment1_ratings','segment2_snapshots','segment2_behaviors','segment2_ratings','feedback'])
        self.assertEqual(r['slots'][3]['contentPath'],r['slots'][6]['contentPath'])
    def test_12_missing_binding_refused(self):
        with self.assertRaisesRegex(ValueError,'固定来源'):p.materialize(self.recipes['recipes/rtop.json'],{})
    def test_13_synthetic_binding_shape_and_distinct_blocks(self):
        r=self.recipes['recipes/teach-primary.json']
        bindings={s['contentPath']:dict(provider='PRIVATE_VERSION',kind=s['kind'],versionId=str(uuid.uuid5(uuid.NAMESPACE_URL,'TEST-ONLY:'+s['contentPath'])),contentHash=hashlib.sha256(('TEST-ONLY:'+s['contentPath']).encode()).hexdigest()) for s in r['slots']}
        d=p.materialize(r,bindings)
        self.assertEqual(set(d),{'schemaVersion','adapterVersion','administration','instruction','blocks'})
        self.assertEqual(len({b['blockId'] for b in d['blocks']}),8)
        self.assertEqual(d['blocks'][3]['source'],d['blocks'][6]['source'])
        self.assertNotEqual(d['blocks'][3]['blockId'],d['blocks'][6]['blockId'])
        # Synthetic output remains in memory; it is not a deployment reference.
    def test_14_wrong_source_kind_refused(self):
        r=self.recipes['recipes/licc.json'];bindings={r['slots'][0]['contentPath']:dict(provider='LIBRARY_SCALE',kind='SCALE')}
        with self.assertRaisesRegex(ValueError,'不匹配'):p.materialize(r,bindings)
    def test_15_deterministic_files_and_hashes(self):
        with tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
            x=p.build(pathlib.Path(a));y=p.build(pathlib.Path(b));self.assertEqual(x,y)
            for row in x['files']:
                data=(pathlib.Path(a)/row['path']).read_bytes()
                self.assertEqual(data,(pathlib.Path(b)/row['path']).read_bytes())
                self.assertEqual(hashlib.sha256(data).hexdigest(),row['sha256'])

class Recorder(unittest.TextTestResult):
    def startTest(self,test):super().startTest(test);self.started=time.perf_counter()
    def addSuccess(self,test):super().addSuccess(test);self.rows.append(dict(test=test.id(),status='PASS',seconds=time.perf_counter()-self.started))
    def addFailure(self,test,err):super().addFailure(test,err);self.rows.append(dict(test=test.id(),status='FAIL',detail=self._exc_info_to_string(err,test)))
    def addError(self,test,err):super().addError(test,err);self.rows.append(dict(test=test.id(),status='ERROR',detail=self._exc_info_to_string(err,test)))
    def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.rows=[]

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ContentChecks)
    result=unittest.TextTestRunner(verbosity=2,resultclass=Recorder).run(suite)
    evidence=dict(kind='UNSIGNED_LOCAL_ARTIFACT_CHECKS',baseline=p.BASE,python=platform.python_version(),
                  execution='current isolated conversation container',results=result.rows,
                  inputs={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['build_pack.py','teach-data.json','test_pack.py']},
                  notExecuted=['native TypeScript/Zod validators','native scoreScale golden cases','database install/publication','browser','formal CI','production'])
    (ROOT/'validation.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    raise SystemExit(not result.wasSuccessful())

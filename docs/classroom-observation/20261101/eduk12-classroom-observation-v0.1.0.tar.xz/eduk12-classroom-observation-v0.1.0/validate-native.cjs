#!/usr/bin/env node
'use strict';
// Optional, directed check against an existing compiled backend. No build, DB or HTTP.
// This file was syntax-checked only in the packaging environment; native execution is NOTRUN.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const [distArg, nativeArg] = process.argv.slice(2);
if (!distArg || !nativeArg) {
  console.error('Usage: node validate-native.cjs <qualified-backend-dist> <native-package-directory>');
  process.exit(2);
}
const dist = path.resolve(distArg), root = path.resolve(nativeArg);
const load = name => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const {validateFormDefinition} = require(path.join(dist, 'modules/assessment-core/form/definition.js'));
const {validateScaleDefinition} = require(path.join(dist, 'modules/scale/scale-definition.js'));
const {scoreScale} = require(path.join(dist, 'modules/scale/scale-scoring.js'));
const {privateCompositionDefinitionSchema} = require(path.join(dist, 'modules/education-tools/private-tool.composition-contracts.js'));
const results = [];
function check(name, run) {run(); results.push({name, status:'PASS'});}
for (const entry of load('manifest.json').files) {
  if (entry.path.startsWith('forms/')) check(entry.path, () => {
    const result = validateFormDefinition(load(entry.path), {forPreview:true});
    assert.ok(result.definition); assert.deepEqual(result.issues.filter(x => x.severity === 'error'), []);
  });
  if (entry.path.endsWith('.definition.json')) check(entry.path, () => {
    const result = validateScaleDefinition(load(entry.path), {instrumentClass:'CUSTOM_DESCRIPTIVE'});
    assert.ok(result.definition); assert.deepEqual(result.issues.filter(x => x.severity === 'error'), []);
  });
}
const rtop = load('scales/rtop-score-entry.definition.json');
for (const value of [0,2,4]) check('RTOP native golden constant '+value, () => {
  const result=scoreScale(rtop,rtop.items.map(x=>({itemCode:x.itemCode,responseValue:value})));
  for(const s of result.scores) assert.equal(s.value,s.key==='total'?25*value:5*value);
});
check('RTOP native missing item does not become zero', () => {
  const result=scoreScale(rtop,rtop.items.slice(1).map(x=>({itemCode:x.itemCode,responseValue:4})));
  assert.equal(result.scores.find(x=>x.key==='total').value,null);
});
const teach = load('scales/teach-element-ratings.definition.json');
for (const value of [1,3,5]) check('Teach native identity ratings '+value, () => {
  const result=scoreScale(teach,teach.items.map(x=>({itemCode:x.itemCode,responseValue:value})));
  assert.equal(result.scores.length,9); for(const s of result.scores) assert.equal(s.value,value);
});
for(const recipeName of ['licc','rtop','teach-primary']) check('V2 schema synthetic '+recipeName, () => {
  const r=load('recipes/'+recipeName+'.json');
  // Explicitly synthetic schema-only refs: never write or publish this object.
  const d={schemaVersion:2,adapterVersion:'2.0.0',administration:r.administration,instruction:r.instruction,
    blocks:r.slots.map(s=>({blockId:crypto.randomUUID(),instruction:s.instruction,
      source:{provider:'PRIVATE_VERSION',kind:s.kind,versionId:crypto.randomUUID(),contentHash:crypto.createHash('sha256').update('TEST-ONLY:'+s.contentPath).digest('hex')}}))};
  privateCompositionDefinitionSchema.parse(d);
});
console.log(JSON.stringify({kind:'DIRECTED_NATIVE_CONTENT_CHECKS',results,
  excluded:['database','publication eligibility','expert source authorization','browser','CI qualification']},null,2));

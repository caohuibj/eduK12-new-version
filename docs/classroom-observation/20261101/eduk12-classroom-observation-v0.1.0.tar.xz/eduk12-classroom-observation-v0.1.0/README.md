# EduK12 课堂观察候选内容包 v0.1.0

状态：**已生成的候选内容与装配资料，不是已安装或已发布的公共工具。**

基线：`caohuibj/eduK12-new-version@d7d43535c8eac445918ae113a43b1cc04032d310`（main，2026-11-01）。本包不修改业务代码、数据库、权限、生成索引、CI 工作流或生产配置。版本适配以该精确源码为准，不声称生产运行版本与它相同。

## 1. 优化后的边界

**量表计算自身分数和反馈；表单只保存原始记录；普通组合问卷只编排顺序和固定来源。** 本包不创建 BUNDLE，不计算跨工具总分，不给表单添加计分或报告，不建立听评课专用引擎。

| 组合 | 实际交付 | 不应误称为 |
| --- | --- | --- |
| LICC 框架记录 | 基于四维框架编写的原创表单，含观察问题、事实和待讨论问题 | LICC 原 68 观察点全文或标准化量表 |
| RTOP 原表配套 | 25 项评分录入、五个分区与原始总分、证据及观察者反馈 | 已包含原 25 项题文/完整锚点的正式 RTOP 数字译本 |
| Teach Primary 核心观察 | 两个独立观察段；时间快照与行为编码为表单；9 个要素评定为量表 | 世界银行官方中文译本、完整培训包或包含环境附加清单的全工具 |

RTOP 伴随工具必须同时使用原始题表和评分手册；仅凭编号提示不能实施观察。Teach 必须查阅原手册完整锚点。原始文献和权利状态见 `SOURCES.md`，不虚构作者授权、中文效度或科学审核人。

## 2. 内容清单

`native/` 中包含 **6 份 FormDraft V2、2 份 ScaleDefinitionV2、2 份独立量表说明、3 份离线组合装配清单及 1 份清单/摘要文件**。

| 路径 | 用途 |
| --- | --- |
| `forms/context.json` | 课堂信息；不重复录入系统已绑定的教师账号 |
| `forms/evidence.json` | 时点、指标编号、事实及反例；不对文字赋分 |
| `forms/observer-feedback.json` | 观察者意见与行动建议；不是自动反馈报告 |
| `forms/licc-inspired.json` | 原创四维教研记录；不强行将 68 点改成等级题 |
| `forms/teach-snapshots.json` | 一个观察段的 4/9/14 分钟快照，明确区分漏采 |
| `forms/teach-behaviors.json` | 28 个主行为及 1.4a/b 子码，共 30 个编码字段；另有证据字段 |
| `scales/rtop-score-entry.definition.json` | 25 项 0–4 分；五个 0–20 分区及 0–100 原始总分 |
| `scales/teach-element-ratings.definition.json` | 一个观察段的 9 项 1–5 分要素评定；不设总分 |
| `scales/*.instruction.json` | 独立版本化的实施说明 |
| `recipes/*.json` | 符号来源清单；**不是可直接发布的原生 COMPOSITION** |

组合顺序：

- **LICC**：课堂信息 → 四维记录 → 观察者专业反馈。
- **RTOP**：课堂信息 → 现场证据 → 原表配套评分 → 观察者专业反馈。
- **Teach Primary**：课堂信息 → 第 1 段快照 → 第 1 段行为/证据 → 第 1 段要素评分 → 第 2 段快照 → 第 2 段行为/证据 → 第 2 段要素评分 → 观察者专业反馈。

同一个固定叶工具可以在不同块重复引用。Teach 两段使用不同 blockId，独立保存，不平均、不覆盖；不为两个时段复制两套评分定义。

## 3. 关键测量修订

**Teach 不是 28 道 1–5 分题。** 行为先按 L/M/H（有限条目允许 NA）记录，观察者再依据整段证据及原锚点评定 9 个要素的 1–5 分。表单不把 L/M/H 换算成数值，量表不机械平均行为编码。

Teach 采用第二版（2021）手册；常规观察为两个 15 分钟段，每段在第 4、9、14 分钟进行快照。0.1=N 时 0.2=NA；0.1=Y 时按离任务人数规则判读。1.3、4.2 的 NA 仅按原手册适用。漏采不等于 N、NA 或 0。1.4a/b 与总 1.4 都保留，由观察者按原规则填写，本轮不引入表单计算。

RTOP 的 0 是有效最低等级，不是缺失。两份评分定义均使用既有 `complete_required`；证据不足不能用最低分补齐。未完成评分保留为未完成，不冒称有效观察结果。资料记录可独立保留，不因未生成分数而改造计分器。

反馈仅解释本次课堂观察：不造常模、百分位、优秀/合格阈值、诊断、教师排名或稳定能力结论。未验证的中文操作提示不是已验证中文量表。

## 4. 与当前合同的对应

| 对象 | 当前仓库来源 | 本包用法 |
| --- | --- | --- |
| 表单 | `assessment-core/form/definition.ts` | `schemaVersion:2`、既有页面和题型；没有 `score`、scoring 或 report |
| 量表 | `scale/scale-definition.ts` | `schemaVersion:2`、`observer_report`、共享选项、直接按题 sum、单位权重、无常模 |
| 私有量表约束 | `education-tools/private-tool.definition.ts` | 遵守 CUSTOM_DESCRIPTIVE 的已确认限制；不借核心加权能力放宽编辑器 |
| 专家组合 | `education-tools/private-tool.composition-contracts.ts` | schemaVersion 2 / adapterVersion 2.0.0 / TEACHER + EXPERT_REPORT + PERSON |
| 活动接线 | `huiteacher/fieldComposition.service.ts`、`HuiteacherFieldManager.tsx` | 固定来源 → 课堂活动 → 已接受邀请 → 原 START/FINAL → 正式证据 |

以上后端路径前缀均为 `server-version/backend/src/modules/`；前端文件在 `server-version/frontend/src/huiteacher/`。

`native/manifest.json` 中的 `educationExpertApplicability` 是拟采用的来源声明，**不是授权**，不能随意塞入严格的叶定义对象。需通过现有来源编制/批准流程在真实版本上声明；本文与 ZIP 不签发使用权。

`PERSON` 是活动中绑定受评教师的身份，不表示将课堂过程构念改为教师人格或长期能力。非 PERSON 目标目前不带 Scale；PEER 的邀请存在不等于已具备本包 EXPERT_REPORT 结构化评分路径。

专家组合不设置 `contextFields`、纵向指标或群体汇总；专家自身信息不进入教师计分背景。授课教师本人反思必须另用本人任务/既有协作记录，不能让观察者代填，也不在一份问卷中虚构多人交接。

## 5. 接入步骤：沿原流程，不新增导入平台

1. 在已有内容编制/入库流程中准备本包的叶工具，保持来源性质和标题；候选、原版、改编及评分伴随工具不能互相改标。公共标准来源和作者私有工具各走已有通路，不能伪装成自编原作以绕过来源管理。
2. 使用现有原生验证器核对完整定义及实际评分；固定 C/P/R 与实施说明版本。无常模参数是明确选择，不补造常模。
3. 从服务端读取实际固定来源 `provider + kind + versionId + contentHash`，保存为本地 bindings 文件。**不得从文件 SHA-256 推算服务器 contentHash；不得用测试 UUID 发布。**
4. 以装配器生成现有 V2 COMPOSITION 定义，交给原编制、检查与冻结流程；服务端仍执行现有来源适用性、所有权和授权检查。本工具只组装 JSON，不调用写入 API。
5. 在 Teacher 课堂活动草稿中绑定该固定问卷，沿原专家邀请、接受、开放、作答及正式反馈链路使用；不改权限与发布流程。

示例命令（均在解压后的目录中执行）：

```bash
# 从已审阅输入重新生成；不是生产安装，也不是计分
python3 build_pack.py build --out ./native

# bindings 必须来自目标环境的真实固定来源，文件不随本包提供
python3 build_pack.py bind \
  --recipe ./native/recipes/rtop.json \
  --bindings ./actual-bindings.json \
  --out ./rtop.composition.json
```

bindings 顶层键是清单中的 `contentPath`，值采用当前原生来源引用格式；故意不提供可被误当作真实来源的预填 UUID 或 hash。

本包没有“一键导入 ZIP”接口，也没有宣称现有 UI 能直接上传此 ZIP。ZIP 是可审阅内容、原生候选 JSON 和装配工具的交接载体，非新的运行时协议。

## 6. 报告与证据

量表定义包含自身描述性反馈，普通组合问卷不新增报告。Teacher 正式观察证据投影当前展示获准的描述性数字或 WITHHELD，以及表单记录；**不能据此承诺自动展示完整量表报告叙述或自动发送给受评教师**。是否展示、向谁展示仍由原有冻结披露与读者权限决定。

不从原始表单生成 AI 评语，不增加自动计时/事件采样，不做跨观察者平均或跨时段画像。重复观察先保留独立记录；专家纵向数值比较不在本包范围内。

## 7. 本次验证与范围冻结

| 改动 → 具体故障 | 必需检查 → 唯一执行位置 | 可复用证据及预算 |
| --- | --- | --- |
| 新候选 JSON/装配清单 → 字段错、漏项、原计分分区错、伪来源引用 | 离线结构/引用/算法定义边界 15 项 → 当前隔离容器 | `validation.json` 及原始日志；秒级完成，不声称 CI 证据 |
| 原生校验调用脚本 → JavaScript 语法错误 | `node --check validate-native.cjs` → 同一容器 | `syntax-validation.json`；只证明语法 |
| 归档 → 漏文件、损坏、与输入不一致 | ZIP 回读及 SHA-256 → 同一容器 | `archive-receipt.json`（包外） |
| 业务/数据库/权限/前端未改 | 不启动其构建、整体验收或生产检查 | 不借历史通过冒称当前已执行 |

**已执行：15 项离线测试通过；原生校验脚本语法通过。** 离线断言检查声明的结构、范围、分区、唯一键、条件引用、时段隔离、缺失来源拒绝及确定性输出，不替代系统真实校验器。

**未执行：原生 TypeScript/Zod 验证、实际 scoreScale golden、数据库安装/发布、浏览器、正式 CI、生产。** 当前交付状态因此为候选，不是发布就绪证明。未克隆完整仓库/安装依赖，不声称已有匹配的编译后端。

在具有匹配源码及依赖的既有编译产物环境中，下一步可定向执行：

```bash
node validate-native.cjs /path/to/qualified/backend/dist ./native
```

该脚本使用原有 Form/Scale 校验器、scoreScale 与组合 schema，不另造评分器，不启动数据库或构建。需记录真实 dist 来源及输入；成功也不代表发布授权、HTTP、浏览器或 CI 已通过。后续代码变化只复验受影响项，正式证据接纳按仓库既有机制，不自动重跑全平台。

## 8. 后续批次

UTOP 双版本、MCOP²、ISTOF、eleot、FIAS/COPUS 和国内行政评分标准保留在后续目录。尤其 UTOP NA 规则、行政权重、行为时间序列工具应分别核对原文及已有合同，不能用表单计分或新增通用算法引擎掩盖差异。此轮没有将它们写成已完成工具。

## 9. 文件与权利说明

`teach-data.json` 保存世界银行来源、许可、署名及改编/翻译声明；原英文行为名称用于明确版本身份。LICC 衍生字段、装配代码及报告说明为本轮生成内容。RTOP 原题表没有镜像进包。权利标签与科学成熟度分别记录，不新增作者联系或实测数据的行政门禁。

`validation.json` 是未签名本地记录，既不是人工科学审核，也不是正式发布凭证。测试中的合成 UUID/哈希只在内存中用于结构检查，不保存为可用绑定，不进入真实账号、生产记录或权限表。
